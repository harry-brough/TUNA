# TUNA

Welcome to TUNA! A user-friendly quantum chemistry program for diatomics.