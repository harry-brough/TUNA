"""
TUNA

An user-friendly quantum chemistry program for diatomics.
"""

__version__ = "0.4.1"
__author__ = 'Harry Brough'